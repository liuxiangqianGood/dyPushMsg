package com.qian.hehemsg.service.impl;

import com.qian.hehemsg.api.LoveApi;
import com.qian.hehemsg.api.WeatherApi;
import com.qian.hehemsg.api.WxApi;
import com.qian.hehemsg.service.WxTemplateService;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Xiangqian Liu
 * @createTime 2022-08-22 13:18:00
 * @Description 模板业务层
 */
@Service
@Slf4j
public class WxTemplateServiceImpl implements WxTemplateService {



    @Override
    public String pushWxTemplateForMyLove() {

        JSONObject object=new JSONObject();
        try {
            List list=new ArrayList();
            list.add("oAlOd6T5Bm9zUM4s1MnNaCbccyo8");
            list.add("oAlOd6RKxnEvL2EwIDZAx_gZgDsE");
            for (int i=0;i< list.size();i++){
                String openId= (String) list.get(i);
                CloseableHttpClient httpClient= HttpClients.createDefault();
                String accessToken=WxApi.queryAccessToken();
                String url="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token="+accessToken;
                HttpPost httpPost=new HttpPost(url);
                httpPost.setHeader("Content-type","application/json");
                JSONObject jsonObject=new JSONObject();
                jsonObject.put("touser",openId);
                jsonObject.put("template_id","TRNPM9mL4HRVRbfnYwXLqKx4AWtd804J3Yauz2cOKdM");
                JSONObject jsonObjects=new JSONObject();
                JSONObject firstObject=new JSONObject();
                firstObject.put("value","么西~么西~叮咚~");
                firstObject.put("color","#173177");
                jsonObjects.put("first",firstObject);
                String weatherKaShi=WeatherApi.getWeather("101130901");
                JSONObject object1=new JSONObject();
                object1.put("value",weatherKaShi);
                object1.put("color","#173177");
                jsonObjects.put("keyword1",object1);
                String weatherHangZhou=WeatherApi.getWeather("101210101");
                JSONObject object2=new JSONObject();
                object2.put("value",weatherHangZhou);
                object2.put("color","#173177");
                jsonObjects.put("keyword2",object2);
                String startLoveTime="2022-4-30";
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
                String nowTime=simpleDateFormat.format(new Date());
                long nowDate=simpleDateFormat.parse(nowTime).getTime();
                long startDate=simpleDateFormat.parse(startLoveTime).getTime();
                //相爱时间
                long loveDate= ((nowDate-startDate) / (1000 * 60 * 60 *24)) - 1;
                JSONObject object3=new JSONObject();
                object3.put("value",loveDate+"天");
                object3.put("color","#173177");
                jsonObjects.put("keyword3",object3);
                String time="-06-09";
                SimpleDateFormat yearFormat=new SimpleDateFormat("yyyy");
                String year=yearFormat.format(new Date());
                String lastYear=(Integer.valueOf(year)+1) + time;
                long lastDate=simpleDateFormat.parse(lastYear).getTime();
                //距离生日
                long birthday= ((lastDate-nowDate) / (1000 * 60 * 60 *24)) - 1;
                JSONObject object4=new JSONObject();
                object4.put("value",birthday+"天");
                object4.put("color","#173177");
                jsonObjects.put("keyword4",object4);
                //情话
                String loveMsg=LoveApi.getLoveMsg();
                JSONObject objectRemark = new JSONObject();
                objectRemark.put("value", loveMsg);
                objectRemark.put("color", "#173177");
                jsonObjects.put("remark", objectRemark);
                jsonObject.put("data",jsonObjects);
                StringEntity stringEntity=new StringEntity(jsonObject.toString(), StandardCharsets.UTF_8);
                httpPost.setEntity(stringEntity);
                CloseableHttpResponse response=httpClient.execute(httpPost);
                HttpEntity httpEntity=response.getEntity();
                String result= EntityUtils.toString(httpEntity);
                object.put("result",result);
                httpClient.close();
                response.close();
            }
        }catch (Exception e){
            log.error("推送异常",e);
        }
        return object.toString();
    }
}
