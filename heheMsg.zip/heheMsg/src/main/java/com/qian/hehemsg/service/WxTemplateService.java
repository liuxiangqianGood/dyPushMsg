package com.qian.hehemsg.service;

/**
 * @author Xiangqian Liu
 * @createTime 2022-08-22 13:18:00
 * @Description TODO
 */
public interface WxTemplateService {

    String pushWxTemplateForMyLove();
}
