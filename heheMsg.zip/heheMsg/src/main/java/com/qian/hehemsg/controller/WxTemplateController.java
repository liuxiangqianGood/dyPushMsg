package com.qian.hehemsg.controller;

import com.qian.hehemsg.service.WxTemplateService;
import net.sf.json.JSONObject;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Xiangqian Liu
 * @createTime 2022-08-22 13:11:00
 * @Description TODO
 */
@RestController
@RequestMapping("/api")
public class WxTemplateController {

    @Resource
    WxTemplateService wxTemplateService;

    @PostMapping("/pushWxTemplateForMyLove")
    public String pushWxTemplateForMyLove(){

        String result=wxTemplateService.pushWxTemplateForMyLove();

        return  result;
    }

}
